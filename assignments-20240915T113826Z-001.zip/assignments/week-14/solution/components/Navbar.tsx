/*

import Link from "next/link"

const Navbar = () => {
  return (
    <div className="flex gap-20 justify-center my-20">
      <Link className="border-2 border-gray-400 px-4 py-2 rounded-xl" href="/">Home</Link>
      <Link className="border-2 border-gray-400 px-4 py-2 rounded-xl" href="static-page">Server Page</Link>
      <Link className="border-2 border-gray-400 px-4 py-2 rounded-xl" href="interactive-page">Client Page</Link>
    </div>
  )
}

export default Navbar

*/
